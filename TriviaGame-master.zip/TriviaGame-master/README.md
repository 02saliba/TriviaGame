# TriviaGame
[Trivia Game](https://shikwan.github.io/TriviaGame/)

A simple javascript game with lively background music, which user has the ability to turn on/off on the top right navbar. 
User can choose other gameplay category in the navigation menu bar. 
